import { useEffect, useMemo, useState } from "react";
import "./App.css";
import Auth from "./Auth.jsx";

const defaultEmployees = [
  {
    id: 1,
    name: "Arjun Mehta",
    email: "arjun@ems.com",
    phone: "+91 98765 11111",
    dept: "Technology",
    designation: "Senior Developer",
    salary: 85000,
    joining: "2026-08-18",
    status: "Active",
  },
  {
    id: 2,
    name: "Priya Sharma",
    email: "priya@ems.com",
    phone: "+91 98765 22222",
    dept: "Finance",
    designation: "Finance Manager",
    salary: 72000,
    joining: "2026-08-12",
    status: "Active",
  },
  {
    id: 3,
    name: "Rohan Kapoor",
    email: "rohan@ems.com",
    phone: "+91 98765 33333",
    dept: "Sales",
    designation: "Sales Executive",
    salary: 48000,
    joining: "2026-08-05",
    status: "Active",
  },
  {
    id: 4,
    name: "Ananya Rao",
    email: "ananya@ems.com",
    phone: "+91 98765 44444",
    dept: "Human Resources",
    designation: "HR Executive",
    salary: 55000,
    joining: "2026-07-29",
    status: "Active",
  },
  {
    id: 5,
    name: "Vikram Singh",
    email: "vikram@ems.com",
    phone: "+91 98765 55555",
    dept: "Operations",
    designation: "Operations Manager",
    salary: 65000,
    joining: "2026-07-20",
    status: "Active",
  },
];

const defaultLoans = [
  {
    id: 1,
    employeeId: 1,
    amount: 100000,
    interest: 8,
    tenure: 12,
    outstanding: 100000,
  },
];

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [authUser, setAuthUser] = useState(null);
  const [authChecking, setAuthChecking] = useState(true);

  const [employees, setEmployees] = useState(() => {
    const saved = localStorage.getItem("ems_employees");
    return saved ? JSON.parse(saved) : defaultEmployees;
  });

  const [attendance, setAttendance] = useState(() => {
    const saved = localStorage.getItem("ems_attendance");
    return saved ? JSON.parse(saved) : {};
  });

  const [loans, setLoans] = useState(() => {
    const saved = localStorage.getItem("ems_loans");
    return saved ? JSON.parse(saved) : defaultLoans;
  });

  const [currentPage, setCurrentPage] = useState("dashboard");
  const [employeeModal, setEmployeeModal] = useState(false);
  const [loanModal, setLoanModal] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState(null);
  const [search, setSearch] = useState("");
  const [departmentFilter, setDepartmentFilter] = useState("");
  const [attendanceEmployee, setAttendanceEmployee] = useState(1);
  const [salaryEmployee, setSalaryEmployee] = useState(1);
  const [toastMessage, setToastMessage] = useState("");

  const [employeeForm, setEmployeeForm] = useState({
    name: "",
    email: "",
    phone: "",
    dept: "Management",
    designation: "",
    salary: "",
    joining: "",
    status: "Active",
  });

  const [loanForm, setLoanForm] = useState({
    employeeId: 1,
    amount: "",
    interest: 8,
    tenure: 12,
  });

  useEffect(() => {
    const token = localStorage.getItem("ems_jwt");

    if (!token) {
      setAuthChecking(false);
      return;
    }

    fetch("http://localhost:8080/api/auth/me", {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
      .then(async (response) => {
        const data = await response.json();
        if (!response.ok) {
          throw new Error(data.message || "Invalid session");
        }
        setAuthUser(data);
        setIsAuthenticated(true);
      })
      .catch(() => {
        localStorage.removeItem("ems_jwt");
        localStorage.removeItem("ems_user");
        setIsAuthenticated(false);
      })
      .finally(() => setAuthChecking(false));
  }, []);

  function handleLogin(user) {
    setAuthUser(user);
    setIsAuthenticated(true);
  }

  function handleLogout() {
    localStorage.removeItem("ems_jwt");
    localStorage.removeItem("ems_user");
    setAuthUser(null);
    setIsAuthenticated(false);
    setCurrentPage("dashboard");
  }

  useEffect(() => {
    localStorage.setItem("ems_employees", JSON.stringify(employees));
  }, [employees]);

  useEffect(() => {
    localStorage.setItem("ems_attendance", JSON.stringify(attendance));
  }, [attendance]);

  useEffect(() => {
    localStorage.setItem("ems_loans", JSON.stringify(loans));
  }, [loans]);

  useEffect(() => {
    if (employees.length > 0) {
      const exists = employees.some(
        (employee) => employee.id === attendanceEmployee
      );

      if (!exists) {
        setAttendanceEmployee(employees[0].id);
      }

      const salaryExists = employees.some(
        (employee) => employee.id === salaryEmployee
      );

      if (!salaryExists) {
        setSalaryEmployee(employees[0].id);
      }

      if (!loanForm.employeeId) {
        setLoanForm((previous) => ({
          ...previous,
          employeeId: employees[0].id,
        }));
      }
    }
  }, [employees]);

  function money(value) {
    return Number(value || 0).toLocaleString("en-IN", {
      maximumFractionDigits: 0,
    });
  }

  function formatDate(date) {
    if (!date) return "-";

    return new Date(date).toLocaleDateString("en-IN", {
      day: "2-digit",
      month: "short",
      year: "numeric",
    });
  }

  function initials(name) {
    return name
      .split(" ")
      .map((word) => word[0])
      .slice(0, 2)
      .join("")
      .toUpperCase();
  }

  function showToast(message) {
    setToastMessage(message);

    setTimeout(() => {
      setToastMessage("");
    }, 2500);
  }

  function attendanceKey(employeeId, day) {
    return `${employeeId}_${day}`;
  }

  function calculateEMI(principal, annualRate, months) {
    if (!principal || !months) return 0;

    if (!annualRate) {
      return principal / months;
    }

    const rate = annualRate / 12 / 100;

    return (
      (principal * rate * Math.pow(1 + rate, months)) /
      (Math.pow(1 + rate, months) - 1)
    );
  }

  function getAttendanceData(employeeId) {
    let present = 0;
    let absent = 0;

    for (let day = 1; day <= 30; day++) {
      const status = attendance[attendanceKey(employeeId, day)];

      if (status === "absent") {
        absent++;
      } else {
        present++;
      }
    }

    return { present, absent };
  }

  function getSalaryData(employee) {
    if (!employee) {
      return {
        present: 0,
        absent: 0,
        adjusted: 0,
        emi: 0,
        net: 0,
      };
    }

    const attendanceData = getAttendanceData(employee.id);

    const adjusted =
      employee.salary -
      (employee.salary / 30) * attendanceData.absent;

    const employeeLoans = loans.filter(
      (loan) =>
        loan.employeeId === employee.id &&
        Number(loan.outstanding) > 0
    );

    const emi = employeeLoans.reduce((total, loan) => {
      return (
        total +
        calculateEMI(
          Number(loan.amount),
          Number(loan.interest),
          Number(loan.tenure)
        )
      );
    }, 0);

    return {
      present: attendanceData.present,
      absent: attendanceData.absent,
      adjusted: Math.max(0, adjusted),
      emi,
      net: Math.max(0, adjusted - emi),
    };
  }

  function changePage(page) {
    setCurrentPage(page);
  }

  function openEmployeeModal(employee = null) {
    setEditingEmployee(employee);

    if (employee) {
      setEmployeeForm({
        name: employee.name,
        email: employee.email,
        phone: employee.phone,
        dept: employee.dept,
        designation: employee.designation,
        salary: employee.salary,
        joining: employee.joining,
        status: employee.status,
      });
    } else {
      setEmployeeForm({
        name: "",
        email: "",
        phone: "",
        dept: "Management",
        designation: "",
        salary: "",
        joining: "",
        status: "Active",
      });
    }

    setEmployeeModal(true);
  }

  function saveEmployee(event) {
    event.preventDefault();

    if (editingEmployee) {
      setEmployees((previous) =>
        previous.map((employee) =>
          employee.id === editingEmployee.id
            ? {
                ...employee,
                ...employeeForm,
                salary: Number(employeeForm.salary),
              }
            : employee
        )
      );

      showToast("Employee updated successfully");
    } else {
      const newEmployee = {
        id: Date.now(),
        ...employeeForm,
        salary: Number(employeeForm.salary),
      };

      setEmployees((previous) => [...previous, newEmployee]);

      showToast("Employee added successfully");
    }

    setEmployeeModal(false);
  }

  function deleteEmployee(id) {
    const confirmed = window.confirm(
      "Are you sure you want to delete this employee?"
    );

    if (!confirmed) return;

    setEmployees((previous) =>
      previous.filter((employee) => employee.id !== id)
    );

    setLoans((previous) =>
      previous.filter((loan) => loan.employeeId !== id)
    );

    showToast("Employee deleted successfully");
  }

  function toggleAttendance(day) {
    if (!attendanceEmployee) return;

    const key = attendanceKey(attendanceEmployee, day);

    setAttendance((previous) => ({
      ...previous,
      [key]: previous[key] === "absent" ? "present" : "absent",
    }));
  }

  function openLoanModal() {
    setLoanForm({
      employeeId: employees[0]?.id || "",
      amount: "",
      interest: 8,
      tenure: 12,
    });

    setLoanModal(true);
  }

  function createLoan(event) {
    event.preventDefault();

    const newLoan = {
      id: Date.now(),
      employeeId: Number(loanForm.employeeId),
      amount: Number(loanForm.amount),
      interest: Number(loanForm.interest),
      tenure: Number(loanForm.tenure),
      outstanding: Number(loanForm.amount),
    };

    setLoans((previous) => [...previous, newLoan]);

    setLoanModal(false);

    showToast("Loan created successfully");
  }

  function printSalary(id) {
    const employee = employees.find(
      (item) => item.id === id
    );

    if (!employee) return;

    const salaryData = getSalaryData(employee);

    const printWindow = window.open("", "_blank");

    printWindow.document.write(`
      <html>
        <head>
          <title>EMS Salary Slip</title>
          <style>
            body {
              font-family: Arial;
              padding: 40px;
              color: #222;
            }

            h1 {
              color: #9b762d;
            }

            table {
              width: 100%;
              border-collapse: collapse;
              margin-top: 30px;
            }

            td {
              padding: 13px;
              border-bottom: 1px solid #ddd;
            }

            .total {
              font-size: 20px;
              font-weight: bold;
            }
          </style>
        </head>

        <body>
          <h1>EMS</h1>
          <h2>Employee Salary Slip</h2>

          <p><b>Employee:</b> ${employee.name}</p>
          <p><b>Department:</b> ${employee.dept}</p>
          <p><b>Designation:</b> ${employee.designation}</p>

          <table>
            <tr>
              <td>Gross Salary</td>
              <td>₹${money(employee.salary)}</td>
            </tr>

            <tr>
              <td>Present Days</td>
              <td>${salaryData.present}</td>
            </tr>

            <tr>
              <td>Absent Days</td>
              <td>${salaryData.absent}</td>
            </tr>

            <tr>
              <td>Attendance Adjusted Salary</td>
              <td>₹${money(salaryData.adjusted)}</td>
            </tr>

            <tr>
              <td>Loan EMI</td>
              <td>- ₹${money(salaryData.emi)}</td>
            </tr>

            <tr class="total">
              <td>NET SALARY</td>
              <td>₹${money(salaryData.net)}</td>
            </tr>
          </table>
        </body>
      </html>
    `);

    printWindow.document.close();
    printWindow.print();
  }

  const filteredEmployees = useMemo(() => {
    return employees.filter((employee) => {
      const matchesSearch =
        employee.name
          .toLowerCase()
          .includes(search.toLowerCase()) ||
        employee.email
          .toLowerCase()
          .includes(search.toLowerCase()) ||
        employee.designation
          .toLowerCase()
          .includes(search.toLowerCase());

      const matchesDepartment =
        !departmentFilter ||
        employee.dept === departmentFilter;

      return matchesSearch && matchesDepartment;
    });
  }, [employees, search, departmentFilter]);

  const latestEmployees = useMemo(() => {
    return [...employees]
      .sort(
        (a, b) =>
          new Date(b.joining) - new Date(a.joining)
      )
      .slice(0, 5);
  }, [employees]);

  const dashboardData = useMemo(() => {
    let payroll = 0;
    let present = 0;
    let absent = 0;

    employees.forEach((employee) => {
      const salaryData = getSalaryData(employee);

      payroll += salaryData.net;
      present += salaryData.present;
      absent += salaryData.absent;
    });

    const total = present + absent;

    const percentage = total
      ? Math.round((present / total) * 100)
      : 0;

    const outstanding = loans.reduce(
      (totalAmount, loan) =>
        totalAmount + Number(loan.outstanding),
      0
    );

    const today = new Date().getDate();

    const presentToday = employees.filter(
      (employee) =>
        attendance[
          attendanceKey(employee.id, today)
        ] !== "absent"
    ).length;

    return {
      payroll,
      present,
      absent,
      percentage,
      outstanding,
      presentToday,
    };
  }, [employees, attendance, loans]);

  const selectedAttendanceData = getAttendanceData(
    attendanceEmployee
  );

  const selectedAttendancePercent =
    selectedAttendanceData.present +
      selectedAttendanceData.absent >
    0
      ? Math.round(
          (selectedAttendanceData.present /
            (selectedAttendanceData.present +
              selectedAttendanceData.absent)) *
            100
        )
      : 0;

  const selectedSalaryEmployee = employees.find(
    (employee) => employee.id === salaryEmployee
  );

  const selectedSalaryData = getSalaryData(
    selectedSalaryEmployee
  );

  const loanPreview = calculateEMI(
    Number(loanForm.amount),
    Number(loanForm.interest),
    Number(loanForm.tenure)
  );

  const pageTitles = {
    dashboard: "Dashboard",
    employees: "Employees",
    attendance: "Attendance",
    salary: "Salary & Payroll",
    loans: "Employee Loans",
    profile: "Company Profile",
  };

  if (authChecking) {
    return (
      <div className="auth-shell">
        <div className="auth-card">
          <div className="auth-brand">EMS</div>
          <p className="auth-description" style={{ textAlign: "center", marginTop: "20px" }}>
            Checking your authentication...
          </p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Auth onLogin={handleLogin} />;
  }

  return (
    <>
      <aside className="sidebar">
        <div className="logo">
          EMS

          <span className="logo-sub">
            EMPLOYEE MANAGEMENT SYSTEM
          </span>
        </div>

        <div className="nav-title">
          Management
        </div>

        <button
          className={`nav-btn ${
            currentPage === "dashboard" ? "active" : ""
          }`}
          onClick={() => changePage("dashboard")}
        >
          ◈ &nbsp; Dashboard
        </button>

        <button
          className={`nav-btn ${
            currentPage === "employees" ? "active" : ""
          }`}
          onClick={() => changePage("employees")}
        >
          ♙ &nbsp; Employees
        </button>

        <button
          className={`nav-btn ${
            currentPage === "attendance" ? "active" : ""
          }`}
          onClick={() => changePage("attendance")}
        >
          ◷ &nbsp; Attendance
        </button>

        <button
          className={`nav-btn ${
            currentPage === "salary" ? "active" : ""
          }`}
          onClick={() => changePage("salary")}
        >
          ₹ &nbsp; Salary & Payroll
        </button>

        <button
          className={`nav-btn ${
            currentPage === "loans" ? "active" : ""
          }`}
          onClick={() => changePage("loans")}
        >
          ◇ &nbsp; Employee Loans
        </button>

        <div className="nav-title">
          System
        </div>

        <button
          className={`nav-btn ${
            currentPage === "profile" ? "active" : ""
          }`}
          onClick={() => changePage("profile")}
        >
          ◎ &nbsp; Company Profile
        </button>
      </aside>

      <main className="main">
        <header className="topbar">
          <div>
            <h1>
              {pageTitles[currentPage]}
            </h1>

            <div className="subtitle">
              Employee Management System
            </div>
          </div>

          <div className="admin">
            <div>
              <strong>
                {authUser?.name || "EMS Administrator"}
              </strong>

              <small
                style={{
                  display: "block",
                  color: "var(--muted)",
                  fontSize: "11px",
                  marginTop: "3px",
                }}
              >
                {authUser?.role || "EMPLOYEE"} · {authUser?.email || ""}
              </small>
            </div>

            <div className="admin-avatar">
              {initials(authUser?.name || "EMS")}
            </div>

            <button
              className="secondary"
              onClick={handleLogout}
              style={{ padding: "9px 12px" }}
            >
              Logout
            </button>
          </div>
        </header>

        {currentPage === "dashboard" && (
          <section className="page active">
            <div className="stats">
              <div className="card stat">
                <div className="stat-icon">
                  ♙
                </div>

                <div className="stat-label">
                  Total Employees
                </div>

                <div className="stat-value">
                  {employees.length}
                </div>
              </div>

              <div className="card stat">
                <div className="stat-icon">
                  ✓
                </div>

                <div className="stat-label">
                  Present Today
                </div>

                <div className="stat-value">
                  {dashboardData.presentToday}
                </div>
              </div>

              <div className="card stat">
                <div className="stat-icon">
                  ₹
                </div>

                <div className="stat-label">
                  Monthly Payroll
                </div>

                <div className="stat-value">
                  ₹{money(dashboardData.payroll)}
                </div>
              </div>

              <div className="card stat">
                <div className="stat-icon">
                  ◇
                </div>

                <div className="stat-label">
                  Outstanding Loans
                </div>

                <div className="stat-value">
                  ₹{money(dashboardData.outstanding)}
                </div>
              </div>
            </div>

            <div className="dashboard-grid">
              <div className="card">
                <div className="section-head">
                  <div>
                    <h2>
                      Latest Employees
                    </h2>

                    <p
                      style={{
                        color: "var(--muted)",
                        fontSize: "11px",
                        marginTop: "5px",
                      }}
                    >
                      Recently joined employees
                    </p>
                  </div>

                  <button
                    className="view-btn"
                    onClick={() =>
                      changePage("employees")
                    }
                  >
                    View All
                  </button>
                </div>

                <div className="latest-list">
                  {latestEmployees.map(
                    (employee) => (
                      <div
                        className="latest-item"
                        key={employee.id}
                      >
                        <div className="emp-avatar">
                          {initials(employee.name)}
                        </div>

                        <div>
                          <div className="emp-name">
                            {employee.name}
                          </div>

                          <div className="emp-info">
                            {employee.designation}
                            {" · "}
                            {employee.dept}
                          </div>
                        </div>

                        <div className="emp-salary">
                          ₹{money(employee.salary)}

                          <div className="emp-date">
                            Joined{" "}
                            {formatDate(
                              employee.joining
                            )}
                          </div>
                        </div>
                      </div>
                    )
                  )}
                </div>
              </div>

              <div className="card">
                <div className="section-head">
                  <h2>
                    Attendance Overview
                  </h2>

                  <button
                    className="view-btn"
                    onClick={() =>
                      changePage("attendance")
                    }
                  >
                    Manage
                  </button>
                </div>

                <div className="attendance-big">
                  {dashboardData.percentage}%
                </div>

                <p
                  style={{
                    color: "var(--muted)",
                    fontSize: "11px",
                  }}
                >
                  Overall attendance this month
                </p>

                <div className="progress">
                  <span
                    style={{
                      width: `${dashboardData.percentage}%`,
                    }}
                  />
                </div>

                <div className="att-row">
                  <span>
                    Present Days
                  </span>

                  <strong>
                    {dashboardData.present}
                  </strong>
                </div>

                <div className="att-row">
                  <span>
                    Absent Days
                  </span>

                  <strong>
                    {dashboardData.absent}
                  </strong>
                </div>
              </div>
            </div>

            <div className="card">
              <div className="section-head">
                <div>
                  <h2>
                    Latest Employee Details
                  </h2>

                  <p
                    style={{
                      color: "var(--muted)",
                      fontSize: "11px",
                      marginTop: "5px",
                    }}
                  >
                    Employee information and current status
                  </p>
                </div>

                <button
                  className="primary"
                  onClick={() =>
                    openEmployeeModal()
                  }
                >
                  + Add Employee
                </button>
              </div>

              <div className="table-wrap">
                <table>
                  <thead>
                    <tr>
                      <th>Employee</th>
                      <th>Department</th>
                      <th>Designation</th>
                      <th>Phone</th>
                      <th>Salary</th>
                      <th>Joining Date</th>
                      <th>Status</th>
                    </tr>
                  </thead>

                  <tbody>
                    {latestEmployees.map(
                      (employee) => (
                        <tr key={employee.id}>
                          <td>
                            <strong>
                              {employee.name}
                            </strong>

                            <div
                              style={{
                                color:
                                  "var(--muted)",
                                fontSize: "10px",
                                marginTop: "3px",
                              }}
                            >
                              {employee.email}
                            </div>
                          </td>

                          <td>
                            {employee.dept}
                          </td>

                          <td>
                            {employee.designation}
                          </td>

                          <td>
                            {employee.phone}
                          </td>

                          <td>
                            ₹
                            {money(
                              employee.salary
                            )}
                          </td>

                          <td>
                            {formatDate(
                              employee.joining
                            )}
                          </td>

                          <td>
                            <span
                              className={`badge ${
                                employee.status ===
                                "Active"
                                  ? "active"
                                  : "inactive"
                              }`}
                            >
                              {employee.status}
                            </span>
                          </td>
                        </tr>
                      )
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </section>
        )}

        {currentPage === "employees" && (
          <section className="page active">
            <div className="card">
              <div className="section-head">
                <h2>
                  Employee Directory
                </h2>

                <button
                  className="primary"
                  onClick={() =>
                    openEmployeeModal()
                  }
                >
                  + Add Employee
                </button>
              </div>

              <div className="search-row">
                <input
                  placeholder="Search employee..."
                  value={search}
                  onChange={(event) =>
                    setSearch(event.target.value)
                  }
                />

                <select
                  value={departmentFilter}
                  onChange={(event) =>
                    setDepartmentFilter(
                      event.target.value
                    )
                  }
                >
                  <option value="">
                    All Departments
                  </option>

                  <option>
                    Management
                  </option>

                  <option>
                    Technology
                  </option>

                  <option>
                    Finance
                  </option>

                  <option>
                    Human Resources
                  </option>

                  <option>
                    Sales
                  </option>

                  <option>
                    Operations
                  </option>
                </select>
              </div>

              <div className="table-wrap">
                <table>
                  <thead>
                    <tr>
                      <th>Employee</th>
                      <th>Department</th>
                      <th>Designation</th>
                      <th>Salary</th>
                      <th>Joining Date</th>
                      <th>Status</th>
                      <th>Actions</th>
                    </tr>
                  </thead>

                  <tbody>
                    {filteredEmployees.map(
                      (employee) => (
                        <tr key={employee.id}>
                          <td>
                            <strong>
                              {employee.name}
                            </strong>

                            <div
                              style={{
                                color:
                                  "var(--muted)",
                                fontSize: "10px",
                                marginTop: "3px",
                              }}
                            >
                              {employee.email}
                            </div>
                          </td>

                          <td>
                            {employee.dept}
                          </td>

                          <td>
                            {employee.designation}
                          </td>

                          <td>
                            ₹
                            {money(
                              employee.salary
                            )}
                          </td>

                          <td>
                            {formatDate(
                              employee.joining
                            )}
                          </td>

                          <td>
                            <span
                              className={`badge ${
                                employee.status ===
                                "Active"
                                  ? "active"
                                  : "inactive"
                              }`}
                            >
                              {employee.status}
                            </span>
                          </td>

                          <td className="actions">
                            <button
                              onClick={() =>
                                openEmployeeModal(
                                  employee
                                )
                              }
                            >
                              Edit
                            </button>

                            <button
                              onClick={() =>
                                deleteEmployee(
                                  employee.id
                                )
                              }
                            >
                              Delete
                            </button>
                          </td>
                        </tr>
                      )
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </section>
        )}

        {currentPage === "attendance" && (
          <section className="page active">
            <div className="card">
              <div className="section-head">
                <h2>
                  Attendance Management
                </h2>

                <select
                  value={attendanceEmployee}
                  onChange={(event) =>
                    setAttendanceEmployee(
                      Number(event.target.value)
                    )
                  }
                  style={{
                    maxWidth: "230px",
                  }}
                >
                  {employees.map(
                    (employee) => (
                      <option
                        key={employee.id}
                        value={employee.id}
                      >
                        {employee.name}
                      </option>
                    )
                  )}
                </select>
              </div>

              <div className="stats">
                <div className="card">
                  <div className="stat-label">
                    Present
                  </div>

                  <div className="stat-value">
                    {
                      selectedAttendanceData.present
                    }
                  </div>
                </div>

                <div className="card">
                  <div className="stat-label">
                    Absent
                  </div>

                  <div className="stat-value">
                    {
                      selectedAttendanceData.absent
                    }
                  </div>
                </div>

                <div className="card">
                  <div className="stat-label">
                    Attendance
                  </div>

                  <div className="stat-value">
                    {
                      selectedAttendancePercent
                    }
                    %
                  </div>
                </div>
              </div>

              <p
                style={{
                  color: "var(--muted)",
                  fontSize: "11px",
                  marginBottom: "15px",
                }}
              >
                Click a date to switch between Present and
                Absent. Salary automatically changes
                according to attendance.
              </p>

              <div className="att-grid">
                {Array.from(
                  { length: 30 },
                  (_, index) => {
                    const day = index + 1;

                    const status =
                      attendance[
                        attendanceKey(
                          attendanceEmployee,
                          day
                        )
                      ] || "present";

                    return (
                      <div
                        key={day}
                        className={`day ${
                          status === "absent"
                            ? "absent-day"
                            : "present-day"
                        }`}
                        onClick={() =>
                          toggleAttendance(day)
                        }
                      >
                        <small>
                          {status === "absent"
                            ? "ABSENT"
                            : "PRESENT"}
                        </small>

                        {day}
                      </div>
                    );
                  }
                )}
              </div>
            </div>
          </section>
        )}

        {currentPage === "salary" && (
          <section className="page active">
            <div className="card">
              <div className="section-head">
                <h2>
                  Salary & Payroll
                </h2>

                <select
                  value={salaryEmployee}
                  onChange={(event) =>
                    setSalaryEmployee(
                      Number(event.target.value)
                    )
                  }
                  style={{
                    maxWidth: "230px",
                  }}
                >
                  {employees.map(
                    (employee) => (
                      <option
                        key={employee.id}
                        value={employee.id}
                      >
                        {employee.name}
                      </option>
                    )
                  )}
                </select>
              </div>

              {selectedSalaryEmployee && (
                <div>
                  <div className="payroll-grid">
                    <div className="payroll-box">
                      <label>
                        EMPLOYEE
                      </label>

                      <strong>
                        {
                          selectedSalaryEmployee.name
                        }
                      </strong>
                    </div>

                    <div className="payroll-box">
                      <label>
                        MONTHLY SALARY
                      </label>

                      <strong>
                        ₹
                        {money(
                          selectedSalaryEmployee.salary
                        )}
                      </strong>
                    </div>

                    <div className="payroll-box">
                      <label>
                        ATTENDANCE
                      </label>

                      <strong>
                        {
                          selectedSalaryData.present
                        }
                        /30
                      </strong>
                    </div>

                    <div className="payroll-box">
                      <label>
                        NET PAYABLE
                      </label>

                      <strong>
                        ₹
                        {money(
                          selectedSalaryData.net
                        )}
                      </strong>
                    </div>
                  </div>

                  <div className="table-wrap">
                    <table>
                      <tbody>
                        <tr>
                          <td>
                            Basic Monthly Salary
                          </td>

                          <td
                            style={{
                              textAlign: "right",
                            }}
                          >
                            ₹
                            {money(
                              selectedSalaryEmployee.salary
                            )}
                          </td>
                        </tr>

                        <tr>
                          <td>
                            Present Days
                          </td>

                          <td
                            style={{
                              textAlign: "right",
                              color:
                                "var(--green)",
                            }}
                          >
                            {
                              selectedSalaryData.present
                            }
                          </td>
                        </tr>

                        <tr>
                          <td>
                            Absent Days
                          </td>

                          <td
                            style={{
                              textAlign: "right",
                              color:
                                "var(--red)",
                            }}
                          >
                            {
                              selectedSalaryData.absent
                            }
                          </td>
                        </tr>

                        <tr>
                          <td>
                            Attendance Adjusted Salary
                          </td>

                          <td
                            style={{
                              textAlign: "right",
                            }}
                          >
                            ₹
                            {money(
                              selectedSalaryData.adjusted
                            )}
                          </td>
                        </tr>

                        <tr>
                          <td>
                            Loan EMI Deduction
                          </td>

                          <td
                            style={{
                              textAlign: "right",
                              color:
                                "var(--red)",
                            }}
                          >
                            - ₹
                            {money(
                              selectedSalaryData.emi
                            )}
                          </td>
                        </tr>

                        <tr
                          style={{
                            fontSize: "17px",
                            fontWeight: "bold",
                          }}
                        >
                          <td>
                            NET PAYABLE
                          </td>

                          <td
                            style={{
                              textAlign: "right",
                              color:
                                "var(--gold2)",
                            }}
                          >
                            ₹
                            {money(
                              selectedSalaryData.net
                            )}
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>

                  <button
                    className="primary"
                    style={{
                      marginTop: "20px",
                    }}
                    onClick={() =>
                      printSalary(
                        selectedSalaryEmployee.id
                      )
                    }
                  >
                    Print Salary Slip
                  </button>
                </div>
              )}
            </div>
          </section>
        )}

        {currentPage === "loans" && (
          <section className="page active">
            <div className="card">
              <div className="section-head">
                <h2>
                  Employee Loans
                </h2>

                <button
                  className="primary"
                  onClick={openLoanModal}
                >
                  + New Loan
                </button>
              </div>

              <div className="table-wrap">
                <table>
                  <thead>
                    <tr>
                      <th>Employee</th>
                      <th>Loan Amount</th>
                      <th>Interest</th>
                      <th>Tenure</th>
                      <th>Monthly EMI</th>
                      <th>Outstanding</th>
                      <th>Status</th>
                    </tr>
                  </thead>

                  <tbody>
                    {loans.length === 0 && (
                      <tr>
                        <td
                          colSpan="7"
                          style={{
                            textAlign: "center",
                            color:
                              "var(--muted)",
                          }}
                        >
                          No loans recorded.
                        </td>
                      </tr>
                    )}

                    {loans.map((loan) => {
                      const employee =
                        employees.find(
                          (item) =>
                            item.id ===
                            loan.employeeId
                        );

                      if (!employee) return null;

                      const emi = calculateEMI(
                        loan.amount,
                        loan.interest,
                        loan.tenure
                      );

                      return (
                        <tr key={loan.id}>
                          <td>
                            <strong>
                              {employee.name}
                            </strong>
                          </td>

                          <td>
                            ₹{money(loan.amount)}
                          </td>

                          <td>
                            {loan.interest}%
                          </td>

                          <td>
                            {loan.tenure} months
                          </td>

                          <td>
                            ₹{money(emi)}
                          </td>

                          <td>
                            ₹
                            {money(
                              loan.outstanding
                            )}
                          </td>

                          <td>
                            <span className="badge loan-badge">
                              {loan.outstanding > 0
                                ? "Active"
                                : "Paid"}
                            </span>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </section>
        )}

        {currentPage === "profile" && (
          <section className="page active">
            <div className="card profile-card">
              <div className="profile-header">
                <div className="profile-avatar">
                  EMS
                </div>

                <div>
                  <h2>
                    EMS Administration
                  </h2>

                  <p
                    style={{
                      color: "var(--muted)",
                      fontSize: "12px",
                      marginTop: "5px",
                    }}
                  >
                    Employee Management System
                  </p>
                </div>
              </div>

              <div className="form-grid">
                <div className="field">
                  <label>
                    COMPANY NAME
                  </label>

                  <input defaultValue="EMS" />
                </div>

                <div className="field">
                  <label>
                    COMPANY EMAIL
                  </label>

                  <input defaultValue="admin@ems.com" />
                </div>

                <div className="field">
                  <label>
                    PHONE
                  </label>

                  <input defaultValue="+91 98765 43210" />
                </div>

                <div className="field">
                  <label>
                    SYSTEM
                  </label>

                  <input
                    defaultValue="Employee Management System"
                    disabled
                  />
                </div>
              </div>

              <button
                className="primary"
                style={{
                  marginTop: "20px",
                }}
                onClick={() =>
                  showToast(
                    "Company information saved"
                  )
                }
              >
                Save Changes
              </button>
            </div>
          </section>
        )}
      </main>

      {employeeModal && (
        <div
          className="modal"
          onClick={(event) => {
            if (event.target === event.currentTarget) {
              setEmployeeModal(false);
            }
          }}
        >
          <div className="modal-box">
            <div className="modal-head">
              <h2>
                {editingEmployee
                  ? "Edit Employee"
                  : "Add Employee"}
              </h2>

              <button
                className="close"
                type="button"
                onClick={() =>
                  setEmployeeModal(false)
                }
              >
                ×
              </button>
            </div>

            <form onSubmit={saveEmployee}>
              <div className="form-grid">
                <div className="field">
                  <label>
                    FULL NAME
                  </label>

                  <input
                    required
                    value={employeeForm.name}
                    onChange={(event) =>
                      setEmployeeForm({
                        ...employeeForm,
                        name: event.target.value,
                      })
                    }
                  />
                </div>

                <div className="field">
                  <label>
                    EMAIL
                  </label>

                  <input
                    type="email"
                    required
                    value={employeeForm.email}
                    onChange={(event) =>
                      setEmployeeForm({
                        ...employeeForm,
                        email: event.target.value,
                      })
                    }
                  />
                </div>

                <div className="field">
                  <label>
                    PHONE
                  </label>

                  <input
                    required
                    value={employeeForm.phone}
                    onChange={(event) =>
                      setEmployeeForm({
                        ...employeeForm,
                        phone: event.target.value,
                      })
                    }
                  />
                </div>

                <div className="field">
                  <label>
                    DEPARTMENT
                  </label>

                  <select
                    value={employeeForm.dept}
                    onChange={(event) =>
                      setEmployeeForm({
                        ...employeeForm,
                        dept: event.target.value,
                      })
                    }
                  >
                    <option>
                      Management
                    </option>

                    <option>
                      Technology
                    </option>

                    <option>
                      Finance
                    </option>

                    <option>
                      Human Resources
                    </option>

                    <option>
                      Sales
                    </option>

                    <option>
                      Operations
                    </option>
                  </select>
                </div>

                <div className="field">
                  <label>
                    DESIGNATION
                  </label>

                  <input
                    required
                    value={
                      employeeForm.designation
                    }
                    onChange={(event) =>
                      setEmployeeForm({
                        ...employeeForm,
                        designation:
                          event.target.value,
                      })
                    }
                  />
                </div>

                <div className="field">
                  <label>
                    MONTHLY SALARY (₹)
                  </label>

                  <input
                    type="number"
                    min="0"
                    required
                    value={employeeForm.salary}
                    onChange={(event) =>
                      setEmployeeForm({
                        ...employeeForm,
                        salary: event.target.value,
                      })
                    }
                  />
                </div>

                <div className="field">
                  <label>
                    JOINING DATE
                  </label>

                  <input
                    type="date"
                    required
                    value={employeeForm.joining}
                    onChange={(event) =>
                      setEmployeeForm({
                        ...employeeForm,
                        joining: event.target.value,
                      })
                    }
                  />
                </div>

                <div className="field">
                  <label>
                    STATUS
                  </label>

                  <select
                    value={employeeForm.status}
                    onChange={(event) =>
                      setEmployeeForm({
                        ...employeeForm,
                        status: event.target.value,
                      })
                    }
                  >
                    <option>
                      Active
                    </option>

                    <option>
                      Inactive
                    </option>
                  </select>
                </div>
              </div>

              <div className="form-actions">
                <button
                  type="button"
                  className="secondary"
                  onClick={() =>
                    setEmployeeModal(false)
                  }
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  className="primary"
                >
                  Save Employee
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {loanModal && (
        <div
          className="modal"
          onClick={(event) => {
            if (event.target === event.currentTarget) {
              setLoanModal(false);
            }
          }}
        >
          <div className="modal-box">
            <div className="modal-head">
              <h2>
                Create Employee Loan
              </h2>

              <button
                className="close"
                type="button"
                onClick={() =>
                  setLoanModal(false)
                }
              >
                ×
              </button>
            </div>

            <form onSubmit={createLoan}>
              <div className="form-grid">
                <div className="field">
                  <label>
                    EMPLOYEE
                  </label>

                  <select
                    required
                    value={loanForm.employeeId}
                    onChange={(event) =>
                      setLoanForm({
                        ...loanForm,
                        employeeId:
                          event.target.value,
                      })
                    }
                  >
                    {employees.map(
                      (employee) => (
                        <option
                          key={employee.id}
                          value={employee.id}
                        >
                          {employee.name}
                        </option>
                      )
                    )}
                  </select>
                </div>

                <div className="field">
                  <label>
                    LOAN AMOUNT (₹)
                  </label>

                  <input
                    type="number"
                    min="1"
                    required
                    value={loanForm.amount}
                    onChange={(event) =>
                      setLoanForm({
                        ...loanForm,
                        amount: event.target.value,
                      })
                    }
                  />
                </div>

                <div className="field">
                  <label>
                    ANNUAL INTEREST (%)
                  </label>

                  <input
                    type="number"
                    min="0"
                    step="0.1"
                    required
                    value={loanForm.interest}
                    onChange={(event) =>
                      setLoanForm({
                        ...loanForm,
                        interest:
                          event.target.value,
                      })
                    }
                  />
                </div>

                <div className="field">
                  <label>
                    TENURE (MONTHS)
                  </label>

                  <input
                    type="number"
                    min="1"
                    required
                    value={loanForm.tenure}
                    onChange={(event) =>
                      setLoanForm({
                        ...loanForm,
                        tenure: event.target.value,
                      })
                    }
                  />
                </div>
              </div>

              <div
                className="payroll-box"
                style={{
                  marginTop: "15px",
                }}
              >
                <label>
                  ESTIMATED MONTHLY EMI
                </label>

                <strong>
                  ₹{money(loanPreview)}
                </strong>
              </div>

              <div className="form-actions">
                <button
                  type="button"
                  className="secondary"
                  onClick={() =>
                    setLoanModal(false)
                  }
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  className="primary"
                >
                  Create Loan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div
        id="toast"
        className={
          toastMessage ? "show" : ""
        }
      >
        {toastMessage}
      </div>
    </>
  );
}

export default App;