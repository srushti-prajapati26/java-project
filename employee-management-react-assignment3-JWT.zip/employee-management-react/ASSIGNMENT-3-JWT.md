# Assignment 3 – Employee Management System JWT

## Requirement
Implement a login and registration system with JWT.

## Project
This implementation adds a Spring Boot authentication backend to the existing React Employee Management System.

### Frontend
- React + Vite
- Login page
- Registration page
- JWT stored in browser localStorage
- Dashboard is shown only after JWT authentication

### Backend
Spring Boot runs on:
`http://localhost:8080`

Endpoints:
- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/auth/me` (JWT-protected verification)

## Run the project

### Terminal 1 – backend
Open a terminal inside `employee-management-react/backend`:

```bash
mvn spring-boot:run
```

### Terminal 2 – frontend
Open a terminal inside `employee-management-react`:

```bash
npm install
npm run dev
```

Open the Vite URL, normally:
`http://localhost:5173`

## Demo account
Email: `admin@ems.com`
Password: `admin123`

You can also register a new account.

## Suggested practical screenshots
1. Registration/Login page showing successful authentication.
2. Employee Management dashboard visible after login, with the logged-in user's name and the existing employee data.

Do not include `node_modules` when sharing the project ZIP. Run `npm install` on another laptop.
