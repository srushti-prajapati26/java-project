package com.employeemanagement.ems.security;

import com.employeemanagement.ems.model.User;
import org.springframework.stereotype.Service;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Base64;

@Service
public class JwtService {
    // Demo secret for the college practical. Replace with an environment variable in production.
    private static final String SECRET = "EMS_Assignment3_JWT_Secret_2026_ChangeThisKey";
    private static final long EXPIRATION_SECONDS = 60 * 60 * 4; // 4 hours

    public String generateToken(User user) {
        String header = base64Url("{"alg":"HS256","typ":"JWT"}");
        long now = Instant.now().getEpochSecond();
        long exp = now + EXPIRATION_SECONDS;

        String payload = base64Url(
            "{"sub":"" + escape(user.getEmail()) +
            "","name":"" + escape(user.getName()) +
            "","role":"" + escape(user.getRole()) +
            "","iat":" + now +
            ","exp":" + exp + "}"
        );

        String unsigned = header + "." + payload;
        return unsigned + "." + sign(unsigned);
    }

    public String getEmail(String token) {
        String[] parts = token.split("\\.");
        if (parts.length != 3 || !verify(parts[0] + "." + parts[1], parts[2])) {
            throw new IllegalArgumentException("Invalid JWT.");
        }

        String payload = new String(
            Base64.getUrlDecoder().decode(parts[1]),
            StandardCharsets.UTF_8
        );

        String email = readStringClaim(payload, "sub");
        long exp = readLongClaim(payload, "exp");

        if (email == null || Instant.now().getEpochSecond() >= exp) {
            throw new IllegalArgumentException("JWT has expired.");
        }

        return email;
    }

    private boolean verify(String unsigned, String signature) {
        return constantTimeEquals(sign(unsigned), signature);
    }

    private String sign(String value) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(SECRET.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
            return Base64.getUrlEncoder().withoutPadding()
                .encodeToString(mac.doFinal(value.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception ex) {
            throw new IllegalStateException("Unable to sign JWT.", ex);
        }
    }

    private String base64Url(String value) {
        return Base64.getUrlEncoder().withoutPadding()
            .encodeToString(value.getBytes(StandardCharsets.UTF_8));
    }

    private boolean constantTimeEquals(String a, String b) {
        return java.security.MessageDigest.isEqual(
            a.getBytes(StandardCharsets.UTF_8),
            b.getBytes(StandardCharsets.UTF_8)
        );
    }

    private String escape(String value) {
        return value.replace("\\", "\\\\").replace(""", "\\"");
    }

    private String readStringClaim(String json, String key) {
        String marker = """ + key + "":"";
        int start = json.indexOf(marker);
        if (start < 0) return null;
        start += marker.length();
        int end = json.indexOf(""", start);
        return end < 0 ? null : json.substring(start, end);
    }

    private long readLongClaim(String json, String key) {
        String marker = """ + key + "":";
        int start = json.indexOf(marker);
        if (start < 0) return 0;
        start += marker.length();
        int end = start;
        while (end < json.length() && Character.isDigit(json.charAt(end))) end++;
        try {
            return Long.parseLong(json.substring(start, end));
        } catch (Exception ex) {
            return 0;
        }
    }
}
