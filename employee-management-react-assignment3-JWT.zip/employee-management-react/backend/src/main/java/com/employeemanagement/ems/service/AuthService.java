package com.employeemanagement.ems.service;

import com.employeemanagement.ems.model.User;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class AuthService {
    private final Map<String, User> users = new ConcurrentHashMap<>();
    private final SecureRandom random = new SecureRandom();

    public AuthService() {
        // Demo account for testing the assignment immediately.
        register("EMS Administrator", "admin@ems.com", "admin123", "ADMIN");
    }

    public synchronized void register(String name, String email, String password, String role) {
        String normalizedEmail = normalize(email);
        if (users.containsKey(normalizedEmail)) {
            throw new IllegalArgumentException("An account with this email already exists.");
        }

        if (name == null || name.isBlank() || password == null || password.length() < 6) {
            throw new IllegalArgumentException("Name is required and password must contain at least 6 characters.");
        }

        String salt = randomSalt();
        users.put(
            normalizedEmail,
            new User(name.trim(), normalizedEmail, hashPassword(password, salt) + ":" + salt, role)
        );
    }

    public User authenticate(String email, String password) {
        User user = users.get(normalize(email));
        if (user == null || !verifyPassword(password, user.getPasswordHash())) {
            throw new IllegalArgumentException("Invalid email or password.");
        }
        return user;
    }

    public User findByEmail(String email) {
        return users.get(normalize(email));
    }

    private String normalize(String email) {
        return email == null ? "" : email.trim().toLowerCase();
    }

    private String randomSalt() {
        byte[] bytes = new byte[16];
        random.nextBytes(bytes);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }

    private String hashPassword(String password, String salt) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] result = digest.digest(
                (salt + ":" + password).getBytes(StandardCharsets.UTF_8)
            );
            return Base64.getEncoder().encodeToString(result);
        } catch (Exception ex) {
            throw new IllegalStateException("Unable to hash password.", ex);
        }
    }

    private boolean verifyPassword(String password, String stored) {
        if (password == null || stored == null || !stored.contains(":")) return false;
        String[] parts = stored.split(":", 2);
        return MessageDigest.isEqual(
            parts[0].getBytes(StandardCharsets.UTF_8),
            hashPassword(password, parts[1]).getBytes(StandardCharsets.UTF_8)
        );
    }
}
