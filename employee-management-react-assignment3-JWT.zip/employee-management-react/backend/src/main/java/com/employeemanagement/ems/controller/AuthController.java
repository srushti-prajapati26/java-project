package com.employeemanagement.ems.controller;

import com.employeemanagement.ems.model.AuthRequests.LoginRequest;
import com.employeemanagement.ems.model.AuthRequests.RegisterRequest;
import com.employeemanagement.ems.model.User;
import com.employeemanagement.ems.security.JwtService;
import com.employeemanagement.ems.service.AuthService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "http://localhost:5173")
public class AuthController {
    private final AuthService authService;
    private final JwtService jwtService;

    public AuthController(AuthService authService, JwtService jwtService) {
        this.authService = authService;
        this.jwtService = jwtService;
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody RegisterRequest request) {
        try {
            authService.register(request.getName(), request.getEmail(), request.getPassword(), "EMPLOYEE");
            return ResponseEntity.ok(Map.of(
                "message", "Registration successful. Please login.",
                "status", "SUCCESS"
            ));
        } catch (IllegalArgumentException ex) {
            return ResponseEntity.badRequest().body(Map.of(
                "message", ex.getMessage(),
                "status", "ERROR"
            ));
        }
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest request) {
        try {
            User user = authService.authenticate(request.getEmail(), request.getPassword());
            String token = jwtService.generateToken(user);

            Map<String, Object> response = new LinkedHashMap<>();
            response.put("message", "Login successful.");
            response.put("status", "SUCCESS");
            response.put("token", token);
            response.put("user", Map.of(
                "name", user.getName(),
                "email", user.getEmail(),
                "role", user.getRole()
            ));

            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException ex) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of(
                "message", ex.getMessage(),
                "status", "ERROR"
            ));
        }
    }

    @GetMapping("/me")
    public ResponseEntity<?> me(@RequestHeader(value = "Authorization", required = false) String authorization) {
        try {
            if (authorization == null || !authorization.startsWith("Bearer ")) {
                throw new IllegalArgumentException("Missing JWT.");
            }

            String email = jwtService.getEmail(authorization.substring(7));
            User user = authService.findByEmail(email);

            if (user == null) {
                throw new IllegalArgumentException("User not found.");
            }

            return ResponseEntity.ok(Map.of(
                "name", user.getName(),
                "email", user.getEmail(),
                "role", user.getRole()
            ));
        } catch (IllegalArgumentException ex) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of(
                "message", ex.getMessage(),
                "status", "UNAUTHORIZED"
            ));
        }
    }
}
